<?php

/*
#######################################
#     e107 website system plguin      #
#     AACGC Eversion Plugin Update    #   
#     by M@CH!N3                      #
#     http://www.AACGC.com            #
#######################################
*/

$evrsn_url="http://www.aacgc.com/e107_plugins/e_version/xml/eversion.xml";



?>

