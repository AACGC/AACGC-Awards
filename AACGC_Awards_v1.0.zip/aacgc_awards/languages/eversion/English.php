<?php
// This section needs to be included in the language file for the plugins update check
define("EVERSION_U1", "plugin.php does not exist in the plugin directory");
define("EVERSION_U2", "e_update.php does not exist in the plugin directory");
define("EVERSION_U3", "Checking for updates to plugin :");
define("EVERSION_U4", "The Current Version on your server is :");
define("EVERSION_U5", "Check for Updates");
define("EVERSION_U6", "Unable to reach update site to check for version information");
define("EVERSION_U7", "There is a new version available");
define("EVERSION_U8", "However, it is a beta version.");
define("EVERSION_U9", "You are up to date. You have the current version installed.");
define("EVERSION_U10", "The update site has no details on this plugin. Contact the plugin author directly.");
define("EVERSION_U11", "Checking for Updates");
define("EVERSION_U12", "Results");
define("EVERSION_U13", "View the details on this version or download it at");
define("EVERSION_U14", "Click Here");
define("EVERSION_U15", "Description :");
define("EVERSION_U16", "Update Check");
define("EVERSION_U17", "It was released on :");
define("EVERSION_U18", "Plugin Author :");
define("EVERSION_U19", "Plugin Manager reports that version ");
define("EVERSION_U20", "is installed. Check the Plugin Manager.");
define("EVERSION_U21", "Stable");
// end include

?>